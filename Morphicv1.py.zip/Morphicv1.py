import sys
from llvmlite import ir, binding

class Morphic:
    def __init__(self, src_code):
        self.src_code = src_code
        self.index = 0
        self.builder = None
        self.module = ir.Module(name='Morphic')
        self.scope = {}

    def compile(self):
        self.init_llvm()
        self.parse()
        return self.module

    def init_llvm(self):
        binding.initialize()
        binding.initialize_native_target()
        binding.initialize_native_asmprinter()

    def parse(self):
        while self.index < len(self.src_code):
            if self.src_code[self.index] == '{':
                self.parse_block()
            self.index += 1

    def parse_block(self):
        self.index += 1
        while self.src_code[self.index] != '}':
            self.parse_statement()
            self.index += 1

    def parse_statement(self):
        if self.src_code.startswith('int', self.index):
            self.parse_declaration()

    def parse_declaration(self):
        self.index += 3
        var_name = self.parse_identifier()
        self.consume_whitespace()
        if self.src_code[self.index] == '=':
            self.index += 1
            self.consume_whitespace()
            value = self.parse_int()
            self.scope[var_name] = ir.Constant(ir.IntType(32), value)
        self.consume(';')

    def parse_identifier(self):
        start = self.index
        while self.src_code[self.index].isalnum() or self.src_code[self.index] == '_':
            self.index += 1
        return self.src_code[start:self.index]

    def parse_int(self):
        start = self.index
        while self.src_code[self.index].isdigit():
            self.index += 1
        return int(self.src_code[start:self.index])

    def consume(self, char):
        self.consume_whitespace()
        assert self.src_code[self.index] == char
        self.index += 1

    def consume_whitespace(self):
        while self.src_code[self.index].isspace():
            self.index += 1

def main():
    if len(sys.argv) < 2:
        print('Usage: python morphic.py <source-file>')
        sys.exit(1)

    with open(sys.argv[1], 'r') as f:
        src_code = f.read()

    compiler = Morphic(src_code)
    module = compiler.compile()
    print(module)

if __name__ == '__main__':
    main()
